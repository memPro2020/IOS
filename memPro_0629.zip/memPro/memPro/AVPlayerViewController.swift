//
//  AVPlayerViewController.swift
//  memPro
//
//  Created by DS on 2020/06/29.
//  Copyright © 2020 HJ. All rights reserved.
//

//

//  ViewController.swift

//  MoviePlayer

//

//  Created by MacBookPro on 2017. 11. 28..

//  Copyright © 2017년 MacBookPro. All rights reserved.

//



import UIKit

import AVKit

import AVFoundation







class viewController: UIViewController {



    override func viewDidLoad() {

        super.viewDidLoad()

        // Do any additional setup after loading the view, typically from a nib.

    }



    override func didReceiveMemoryWarning() {

        super.didReceiveMemoryWarning()

        // Dispose of any resources that can be recreated.

    }





    @IBAction func btnInternalMovie(_ sender: UIButton) {

        // 비디오 파일명을 사용하여 비디오가 저장된 앱 내부의 파일 경로를 받아온다.

        let filePath:String? = Bundle.main.path(forResource: "barcodeVideo", ofType: "mp4")

        //앱내부의 파일명을 nsurl형식으로 변경한다.
        let url = NSURL(fileURLWithPath: filePath!)

        playVideo(url: url)

    }

    
    private func playVideo(url: NSURL){

        //avplayerViewController의 인스턴스를 생성한다.

        let playerController = AVPlayerViewController()

        //앞에서 얻은 비디오 url로 초기화된 avplayer의 인스턴스를 생성한다.

        let player = AVPlayer(url: url as URL)

        //AVPlayViewController의 player 속성에 위에서 생성한 avplayer인스턴스를 할당한다.

        playerController.player = player

        //비디오를 재생한다.
        self.present(playerController, animated:true){

            player.play()

        }

 

        





    }

}
